from get_d4j_bug_list import get_history_defects4j_project_and_bug

defects4j_history_bugs = get_history_defects4j_project_and_bug("/Users/tom/Downloads/defects4j-1.2.0")
selfapr_defects4j12 = ['Time_15', 'Lang_6', 'Lang_26', 'Lang_7', 'Math_11', 'Closure_113', 'Closure_73', 'Closure_79',
                       'Closure_109', 'Math_77', 'Math_80', 'Lang_34', 'Closure_6', 'Closure_104', 'Math_79',
                       'Closure_57', 'Mockito_26', 'Chart_1', 'Closure_75', 'Math_46', 'Closure_86', 'Lang_29',
                       'Mockito_5', 'Chart_13', 'Closure_46', 'Math_104', 'Math_82', 'Closure_106', 'Math_32',
                       'Closure_115', 'Closure_11', 'Lang_60', 'Math_30', 'Math_85', 'Math_41', 'Math_75', 'Chart_24',
                       'Closure_31', 'Lang_33', 'Closure_92', 'Chart_20', 'Closure_125', 'Math_72', 'Math_70',
                       'Math_73', 'Time_19', 'Time_7', 'Chart_8', 'Lang_10', 'Closure_38', 'Chart_9', 'Math_63',
                       'Chart_5', 'Closure_70', 'Closure_10', 'Math_94', 'Math_95', 'Math_5', 'Math_49', 'Closure_123',
                       'Math_59', 'Math_57', 'Lang_58', 'Closure_126', 'Mockito_29', 'Lang_21', 'Closure_62', 'Math_50',
                       'Chart_11', 'Lang_51', 'Lang_57', 'Closure_40', 'Chart_7', 'Math_22']
selfapr_defects4j2 = ['Compress_31', 'Cli_8', 'JacksonDatabind_27', 'Jsoup_17', 'Codec_7', 'Compress_18', 'Jsoup_24',
                      'Compress_14', 'JacksonDatabind_34', 'Jsoup_40', 'Cli_25', 'Codec_9', 'JacksonCore_5',
                      'Closure_168', 'Compress_38', 'Jsoup_46', 'JacksonDatabind_83', 'Collections_26', 'Codec_3',
                      'Cli_40', 'Cli_37', 'Cli_12', 'JacksonDatabind_12', 'Jsoup_68', 'Jsoup_41', 'Codec_4',
                      'JacksonCore_8', 'Cli_11', 'JxPath_12', 'JacksonDatabind_17', 'Csv_4', 'JacksonDatabind_99',
                      'JacksonDatabind_16', 'JacksonDatabind_46', 'Codec_8', 'JacksonCore_25', 'Compress_27',
                      'Jsoup_45', 'Jsoup_62', 'JacksonDatabind_57', 'Compress_19', 'Cli_17', 'JacksonDatabind_102',
                      'Gson_6', 'Compress_23', 'Codec_17', 'Codec_16']


def read_csv(file_path="./valid_patches.csv"):
    plausible_fixes_d4j12, plausible_fixes_d4j21 = set(), set()
    with open(file_path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            items = line.split("\t")
            project, bugid = items[2].split("_")[0], items[2].split("_")[1]
            if str(bugid) in defects4j_history_bugs.get(project, []):
                plausible_fixes_d4j12.add(f"{project}_{bugid}")
            else:
                plausible_fixes_d4j21.add(f"{project}_{bugid}")
    return plausible_fixes_d4j12, plausible_fixes_d4j21


if __name__ == '__main__':
    set1, set2 = read_csv()
    print(len(list(set1)), "\n", list(set2))
