import os

cure_defects4j12 = ['Chart_11', 'Closure_62', 'Lang_59', 'Chart_12', 'Lang_6', 'Closure_126', 'Chart_17', 'Closure_70',
                    'Chart_14', 'Chart_1', 'Closure_73', 'Mockito_5', 'Math_98', 'Time_19', 'Math_58', 'Lang_38',
                    'Lang_10', 'Math_70', 'Mockito_29', 'Math_65', 'Math_59', 'Math_75', 'Lang_29', 'Mockito_38',
                    'Closure_11', 'Closure_10', 'Closure_38', 'Lang_26', 'Math_79', 'Math_50', 'Math_2', 'Math_82',
                    'Math_41', 'Math_57', 'Closure_18', 'Math_94', 'Math_80', 'Math_56', 'Lang_51', 'Mockito_8',
                    'Chart_24', 'Math_30', 'Closure_57', 'Chart_26', 'Math_27', 'Closure_40', 'Lang_43', 'Lang_57',
                    'Closure_92', 'Closure_86', 'Closure_102', 'Math_22', 'Math_34', 'Chart_9', 'Chart_8', 'Chart_20',
                    'Closure_46']

cure_defects4j2 = ['JxPath_5', 'JacksonDatabind_37', 'Jsoup_77', 'Jsoup_88', 'Collection_26', 'JacksonCore_25',
                   'Codec_17', 'Closure_168', 'JxPath_10', 'Cli_25', 'Cli_8', 'JacksonCore_5', 'Jsoup_68', 'Codec_4',
                   'JacksonDatabind_16', 'Jsoup_43', 'Codec_7', 'Codec_2', 'Compress_31']


def count_defects4j_bugs(dir="./Defects4Jv2.0"):
    result = []
    for patch in os.listdir(dir):
        result.append(patch.split(".")[0])
    return result


if __name__ == '__main__':
    print(len(count_defects4j_bugs()))
