rewardrepair_defects4j12 = ['Math_57', 'Math_41', 'Time_19', 'Math_30', 'Math_82', 'Lang_29', 'Math_59', 'Math_34',
                            'Lang_45', 'Math_70', 'Closure_101', 'Chart_12', 'Lang_21', 'Lang_59', 'Closure_73',
                            'Math_85', 'Closure_62', 'Chart_24', 'Closure_86', 'Closure_70', 'Closure_18', 'Chart_11',
                            'Math_11', 'Lang_6', 'Closure_31', 'Lang_33', 'Mockito_26', 'Math_33', 'Math_75', 'Math_94',
                            'Math_80', 'Mockito_5', 'Closure_11', 'Chart_1', 'Closure_1', 'Math_50', 'Closure_126',
                            'Closure_92', 'Mockito_38', 'Chart_9', 'Closure_38', 'Math_104', 'Lang_57', 'Math_105',
                            'Math_2']
rewardrepair_defects4j2 = ['Closure_168', 'JxPath_16', 'JacksonDatabind_57', 'Jsoup_52', 'Jsoup_57',
                           'JacksonDatabind_27', 'Jsoup_64', 'JacksonCore_5', 'Csv_11', 'Codec_1', 'JacksonCore_25',
                           'Cli_25', 'JacksonDatabind_102', 'Csv_9', 'Codec_8', 'JxPath_10', 'Cli_8', 'Compress_14',
                           'JacksonDatabind_49', 'Jsoup_24', 'Cli_5', 'JacksonDatabind_17', 'Jsoup_43', 'Codec_7',
                           'JxPath_5', 'Jsoup_55', 'Codec_2', 'Codec_17', 'Cli_27', 'Codec_3', 'Cli_28', 'Jsoup_49',
                           'Compress_27', 'JacksonDatabind_13', 'JacksonDatabind_99', 'Cli_17', 'JxPath_1',
                           'Compress_31', 'Gson_6', 'Compress_19', 'JacksonDatabind_24', 'JacksonDatabind_83',
                           'Collections_26', 'JacksonDatabind_46', 'Jsoup_86']


def count_defects4j_bugs(path="./correct-patches-d4jv2.csv"):
    result = []
    with open(path, "r") as f:
        for line in f.readlines():
            if ("src/" in line and not line.startswith("src/")) or (
                    "source/" in line and not line.startswith("source/")):
                result.append(line.split()[0].strip())
    return result


if __name__ == '__main__':
    print(len(count_defects4j_bugs()))
