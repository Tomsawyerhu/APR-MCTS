rapgen_defects4j12 = ['Chart_1', 'Chart_11', 'Chart_12', 'Chart_16', 'Chart_20', 'Chart_7', 'Chart_8', 'Chart_9',
                      'Closure_104', 'Closure_106', 'Closure_11', 'Closure_113', 'Closure_115', 'Closure_123',
                      'Closure_125', 'Closure_126', 'Closure_18', 'Closure_19', 'Closure_46', 'Closure_57',
                      'Closure_65', 'Closure_70', 'Closure_73', 'Closure_75', 'Closure_77', 'Closure_79', 'Closure_86',
                      'Closure_92', 'Lang_10', 'Lang_26', 'Lang_29', 'Lang_34', 'Lang_35', 'Lang_51', 'Lang_52',
                      'Lang_57', 'Lang_6', 'Lang_60', 'Lang_7', 'Math_104', 'Math_22', 'Math_30', 'Math_34', 'Math_35',
                      'Math_41', 'Math_49', 'Math_5', 'Math_57', 'Math_67', 'Math_70', 'Math_72', 'Math_75', 'Math_77',
                      'Math_79', 'Math_80', 'Math_98', 'Mockito_26', 'Mockito_5', 'Time_19']
rapgen_defects4j2 = ['Cli_17', 'Cli_27', 'Cli_28', 'Cli_32', 'Cli_34', 'Cli_8', 'Closure_150', 'Closure_168',
                     'Codec_17', 'Codec_4', 'Codec_7', 'Codec_8', 'Collections_26', 'Compress_14', 'Compress_19',
                     'Compress_27', 'Compress_31', 'Compress_32', 'Csv_11', 'Csv_15', 'JacksonCore_14',
                     'JacksonCore_25', 'JacksonCore_5', 'JacksonCore_8', 'JacksonDatabind_102', 'JacksonDatabind_107',
                     'JacksonDatabind_13', 'JacksonDatabind_17', 'JacksonDatabind_27', 'JacksonDatabind_34',
                     'JacksonDatabind_46', 'JacksonDatabind_49', 'JacksonDatabind_54', 'JacksonDatabind_83',
                     'JacksonDatabind_99', 'JacksonXml_5', 'Jsoup_17', 'Jsoup_32', 'Jsoup_40', 'Jsoup_41', 'Jsoup_43',
                     'Jsoup_45', 'Jsoup_57', 'Jsoup_62', 'Jsoup_68', 'Jsoup_86', 'JxPath_5']


def count_defects4j_bugs(path="./Defects4J_result_summary_v2p0.csv"):
    result = []
    with open(path, "r") as f:
        for line in f.readlines()[1:]:
            if line.split(",")[-2] == '1':
                t = line.split(",")[2]
                if t.split("_")[0] + "_" + t.split("_")[1] not in result:
                    result.append(t.split("_")[0] + "_" + t.split("_")[1])
                else:
                    print(t)
    return result


if __name__ == '__main__':
    print(len(count_defects4j_bugs()))
