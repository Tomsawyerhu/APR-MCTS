import json
import os

exists=os.listdir("../yi-9b_cot_plausible")
with open("../mcts_llama_8b_16_rollout.jsonl",'r') as f:
    lines = f.readlines()
    for line in lines:
        line=json.loads(line)
        if line["eval"]=="FAIL":
            continue
        if f"{line['project']}-{line['bug_id']}.jsonl" not in exists:
            print(f"{line['project']}-{line['bug_id']}")