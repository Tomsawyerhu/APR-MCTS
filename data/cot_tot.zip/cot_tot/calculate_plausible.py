import json
import os


def get_plausible_patches(path, remove_dup=True):
    patches = []
    with open(path, "r") as f:
        lines = f.readlines()
        for line in lines:
            json_line = json.loads(line)
            if remove_dup and json_line["patch"].strip() not in patches:
                patches.append(json_line["patch"].strip())
            elif not remove_dup:
                patches.append(json_line["patch"].strip())

    return patches


def calculate_avg_plausible(dir="../qwen-3b_tot_plausible", remove_dup=True):
    patches_num, bugs = 0, 0
    for file in os.listdir(dir):
        patches = get_plausible_patches(os.path.join(dir, file), remove_dup)
        patches_num += len(patches)
        bugs += 1
    return patches_num / bugs


def calculate_sum_plausible(dir="../qwen-3b_tot_plausible", remove_dup=True):
    patches_num = 0
    for file in os.listdir(dir):
        patches = get_plausible_patches(os.path.join(dir, file), remove_dup)
        patches_num += len(patches)

    return patches_num


def calculate_avg_attempt_to_reach_first_plausible(fpath="./yi-9b.tot.jsonl"):
    with open(fpath, "r") as f:
        lines = f.readlines()
        attempts = []
        for line in lines:
            json_line = json.loads(line)
            if json_line["eval"] == "PASS":
                attempts.append(json_line["attempt"])
        return sum(attempts) / len(attempts)


print(calculate_avg_plausible("../qwen-7b_cot_plausible",remove_dup=False))
print(calculate_sum_plausible("../qwen-7b_cot_plausible",remove_dup=False))
print(calculate_avg_plausible("../qwen-7b_tot_plausible",remove_dup=False))
print(calculate_sum_plausible("../qwen-7b_tot_plausible",remove_dup=False))

print(calculate_avg_plausible("../qwen-7b_cot_plausible",remove_dup=True))
print(calculate_sum_plausible("../qwen-7b_cot_plausible",remove_dup=True))
print(calculate_avg_plausible("../qwen-7b_tot_plausible",remove_dup=True))
print(calculate_sum_plausible("../qwen-7b_tot_plausible",remove_dup=True))

#
print(calculate_avg_attempt_to_reach_first_plausible("./qwen-7b.cot.jsonl"))
print(calculate_avg_attempt_to_reach_first_plausible("../result_qwen_7b.jsonl"))